﻿using System;
using System.Drawing;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace HomeWork1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private Color inverseColor(Color c)
        {
            return Color.FromArgb(255 - c.R, 255 - c.G, 255 - c.B);
        }

        private void EmailEnter(object sender, EventArgs e)
        {
            emailTB.ForeColor = nameTB.ForeColor;
            if(lblError.Text == "Error: invalid email..!!")
            {
                lblError.Text = "";
            }
        }

        private void colorChose(object sender, EventArgs e)
        {
            if (this.favorateColor.ShowDialog() == DialogResult.OK)
            {
                this.colorBtn.BackColor = this.favorateColor.Color;
                this.colorBtn.ForeColor = inverseColor(this.favorateColor.Color);
                this.colorBtn.Text = this.favorateColor.Color.Name;
            }
        }
        private bool isEmail(string email)
        {
            try
            {
                MailAddress e = new MailAddress(email);
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            if(!Regex.IsMatch(emailTB.Text,pattern:@"^[a-zA-Z0-9.%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"))
            {
                lblError.Text = "Error: invalid email..!!";
                emailTB.ForeColor = lblError.ForeColor;
                return;
            }
            string gender = "";
            if (genderMale.Checked)
                gender = "Male";
            else if (genderFemale.Checked)
                gender = "Female";
            else if (genderNone.Checked)
                gender = "None";
            lblResult.Text = "Name:"+nameTB.Text+",Email:"+emailTB.Text+",Gender:"+gender+"Birthdate:"+birthDate.Value.ToString("dd/MM/yyyy")+
                "Country:";
        }
    }
}
